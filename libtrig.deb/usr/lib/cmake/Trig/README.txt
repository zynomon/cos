1  in your cmakelist.txt add,


find_packages(Trig)

2   and then link with your binary by 

Trig::crash 


3   in your mainwindow class and main do

#include <cosec>

4   then in your mainwindow class ( c++ ) add 

REG_CRASH();

5 then its done!